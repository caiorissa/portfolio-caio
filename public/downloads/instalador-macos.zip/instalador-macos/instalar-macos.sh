#!/bin/bash
set -euo pipefail

# Instalador de ferramentas e aplicativos para macOS.
# Uso: ./instalar-macos.sh
# A variável VORSSAINT_SETTINGS_FILE pode apontar para outro backup .plist.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SETTINGS_FILE="${VORSSAINT_SETTINGS_FILE:-$SCRIPT_DIR/Vorssaint Settings.plist}"
VORSSAINT_DOMAIN="com.vorssaint.utils"

log() { printf '\n==> %s\n' "$*"; }
fail() { printf '\nErro: %s\n' "$*" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || fail 'Este instalador funciona somente no macOS.'
[[ -f "$SETTINGS_FILE" ]] || fail "Não encontrei o backup do Vorssaint: $SETTINGS_FILE"
/usr/bin/plutil -lint "$SETTINGS_FILE" >/dev/null || fail 'O arquivo de configurações do Vorssaint não é um plist válido.'

# O cask oficial do Vorssaint requer Apple Silicon e macOS 14 ou posterior.
ARCH="$(/usr/bin/uname -m)"
OS_MAJOR="$(/usr/bin/sw_vers -productVersion | /usr/bin/cut -d. -f1)"
[[ "$ARCH" == "arm64" ]] || fail 'O Vorssaint requer um Mac com Apple Silicon; nenhum aplicativo foi instalado.'
(( OS_MAJOR >= 14 )) || fail 'O Vorssaint requer macOS 14 ou posterior; nenhum aplicativo foi instalado.'

if ! command -v brew >/dev/null 2>&1; then
  log 'Instalando Homebrew (o instalador oficial pode solicitar sua senha de administrador)'
  NONINTERACTIVE=1 /bin/bash -c "$(/usr/bin/curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Disponibiliza Homebrew no PATH nesta sessão, inclusive em instalações novas.
if [[ -x /opt/homebrew/bin/brew ]]; then
  eval "$(/opt/homebrew/bin/brew shellenv)"
elif [[ -x /usr/local/bin/brew ]]; then
  eval "$(/usr/local/bin/brew shellenv)"
fi
command -v brew >/dev/null 2>&1 || fail 'Homebrew foi instalado, mas não foi encontrado no PATH.'

log 'Atualizando os metadados do Homebrew'
brew update

install_formula() {
  local formula="$1"
  if brew list --formula --versions "$formula" >/dev/null 2>&1; then
    log "$formula já está instalado"
  else
    log "Instalando $formula"
    brew install "$formula"
  fi
}

install_cask() {
  local cask="$1"
  local app_bundle="$2"
  if brew list --cask --versions "$cask" >/dev/null 2>&1; then
    log "$cask já está instalado pelo Homebrew"
    return
  fi
  if [[ -d "/Applications/$app_bundle" || -d "$HOME/Applications/$app_bundle" ]]; then
    log "$app_bundle já existe em Aplicativos"
    return
  fi
  log "Instalando $cask"
  brew install --cask "$cask"
}

install_formula node
install_formula python

# Helium é o navegador Chromium (cask helium-browser), não o antigo app Helium.
install_cask helium-browser Helium.app
install_cask discord Discord.app
install_cask cursor Cursor.app
install_cask anydesk AnyDesk.app
install_cask chatgpt ChatGPT.app
install_cask whatsapp WhatsApp.app
install_cask vorssaint Vorssaint.app
install_cask rectangle Rectangle.app

log 'Aplicando as configurações anexadas do Vorssaint'
# O backup oficial guarda as preferências sob a chave "settings". Extraímos
# esse dicionário para importar no domínio padrão usado pelo aplicativo.
TEMP_SETTINGS="$(/usr/bin/mktemp -t vorssaint-settings)"
cleanup() { /bin/rm -f "$TEMP_SETTINGS"; }
trap cleanup EXIT
/usr/bin/plutil -extract settings xml1 -o "$TEMP_SETTINGS" "$SETTINGS_FILE"

# Evita que um processo aberto mantenha as preferências antigas em memória.
/usr/bin/osascript >/dev/null 2>&1 <<'APPLESCRIPT' || true
if application "Vorssaint" is running then
  tell application "Vorssaint" to quit
end if
APPLESCRIPT
/usr/bin/defaults import "$VORSSAINT_DOMAIN" "$TEMP_SETTINGS"

log 'Abrindo Vorssaint com as configurações restauradas'
/usr/bin/open -a 'Vorssaint'

cat <<'DONE'

Concluído. Homebrew, Node.js, Python e os aplicativos solicitados foram instalados.
O macOS ainda pode pedir permissões de privacidade para recursos específicos do Vorssaint ou do AnyDesk; aprove-as em Ajustes do Sistema quando solicitado.
DONE
